$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "5667fd0a-8079-493a-b24a-9841f7a11c62",
    "feature": "Verification of Create Invoice functionality",
    "scenario": "Create Invoice",
    "start": 1646763495926,
    "group": 1,
    "content": "",
    "tags": "@testinvoice,@createinvoicetest,",
    "end": 1646763549274,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});