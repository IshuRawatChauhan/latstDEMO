package stepdefinitions;

import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import factory.DriverFactory;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.PayablesPage;
import util.CommonMethods;

public class CreateInvoiceSteps {
	
	private CommonMethods cm = new CommonMethods(DriverFactory.getDriver());
	
	private PayablesPage pgInvoice = new PayablesPage(DriverFactory.getDriver());
	
@And("I enter the details in invoice header {string} and {string} and {string} and {string}")
	public void i_enter_the_details_in_invoice_header(String invoicenumber,String  Ccy,String  amount,String supplier) {
	//cm.delay();
	pgInvoice.enterDetailsforInvoiceCreation(invoicenumber, Ccy, amount,supplier);	
}

@And("I enter {string} and {string} and {string} in the invoice header")
public void i_enter_the_values_in_invoice_header(String invoicenumber,String  amount,String supplier) {
//cm.delay();
pgInvoice.enterDetailsInInvoiceHeader(invoicenumber, amount,supplier);	
}


@And("I enter the values in accounting tab")
public void i_enter_the_values_in_accouting_tab() {
//cm.delay();
pgInvoice.enterDetailsInAcccounting();	
}
@And("I verify the saved record")
public void SavedRecord() {
	try {
		Thread.sleep(8000);
	}
	catch(Exception e) {
		System.out.print(e);}
}


@And("I click on Save and Close link")
public void SavePage() {
	pgInvoice.saveClick();
	
}
@And("I verify the error message")
public void verifyErrorMsg() {
   System.out.println("Error Message");
   try {
		Thread.sleep(8000);
	}
	catch(Exception e) {
		System.out.print(e);}
  
}
	
}
