package stepdefinitions;

import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import factory.DriverFactory;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import util.CommonMethods;

public class LoginPageSteps {
	
	private static String title;
	private LoginPage loginPage = new LoginPage(DriverFactory.getDriver());
	private CommonMethods cm = new CommonMethods(DriverFactory.getDriver());
	Properties prop;

	@Given("I verify the User ID and Password field is present")
	public void i_verify_input_field_present() throws IOException {
	
		Assert.assertTrue(loginPage.userNameExists());
		Assert.assertTrue(loginPage.passwordExists());
		
	}
	
	@Given("I verify the login button is present")
	public void i_verify_button_is_displayed() {
		Assert.assertTrue(loginPage.loginButtonExists());
		
	}
	
	@When("user gets the title of the page")
	public void user_gets_the_title_of_the_page()  throws IOException{
		title = loginPage.getLoginPageTitle();
		System.out.println("Page title is: " + title);
	}

	@Then("page title should be {string}")
	public void page_title_should_be(String expectedTitleName) {
		Assert.assertTrue(title.contains(expectedTitleName));
	}

	
	@When("user login the application with {string} and {string}")
	public void user_login_the_application_with(String Uname, String pass) throws IOException {
		loginPage.enterUserName(Uname);
		loginPage.enterPassword(pass);
		loginPage.clickOnLogin();
	}


	@Given("I validate the Home page")
	public void i_verify_home_page() {
		Assert.assertTrue(loginPage.linkExists("Payables"));
		
	}

}
