package stepdefinitions;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import util.CommonMethods;
import factory.DriverFactory;


public class Helper{
	
	private CommonMethods cm = new CommonMethods(DriverFactory.getDriver());
	
	
	@Given("I click on {string} link")
	public void i_click_on_link(String strVal) throws InterruptedException {
	cm.clickLink(strVal);
	Thread.sleep(2000);
	}
	@Given("I verify the link {string} present")
	public void i_verify_link_present(String strVal) {
		Assert.assertTrue(cm.isLinkPresent("strVal"));
	}
	@Given("I click on {string} button")
	public void i_click_on_button(String strVal) throws InterruptedException {
		
	cm.clickButton(strVal);

	Thread.sleep(2000);
	}
	
	@Given("I click on Create button")
	public void i_click_on_create_button() throws InterruptedException {
		Thread.sleep(2000);
	cm.clickCreateButton();

	Thread.sleep(2000);
	}
	
	
	
}
