package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;

public class PayablesPage {

	private WebDriver driver;

	// 2. Constructor of the page class:
	public PayablesPage(WebDriver driver) {
		this.driver = driver;
	}
	
@And("Enter Details")
	public void enterDetailsforInvoiceCreation(String invoicenumber,String  Ccy,String  amount, String supplier) {
	try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.print("/nClick create button/n");
	driver.findElement(By.xpath("//button[@id='pt1:_FOr1:1:_FONSr2:0:_FOTsr1:0:pm1:r1:0:r1:0:ITPdtl:0:AT1:_ATp:ct2']")).click();
	try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.print("/nAfter calling the create button/n");
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i2::content")).sendKeys(invoicenumber);
	
	try {
		Thread.sleep(1000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	Select sc = new Select(driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:soc1::content")));
	System.out.print("Dropdwn :");
	sc.selectByIndex(2);
	
//	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:soc1::content")).sendKeys(Ccy);
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i3::content")).sendKeys(amount);
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i3::content")).sendKeys(Keys.TAB);
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("Before test supplier");
	
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic3::content")).sendKeys(supplier);
    //driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r3:0:ic3::content")).sendKeys(Keys.ENTER);
	    
    System.out.println("After test supplier");
    try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("Before description");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i4::content")).sendKeys("test");
    try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("after description");
	
    driver.findElement(By.xpath("//a[.='Show More']")).click();
	try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	//.click();
	//.selectbyvalue(value);
	
	driver.findElement(By.xpath("//a[.='Accounting']")).click();
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	System.out.println("Before acc date");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:id4::content")).sendKeys("03/01/22");
    try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("after acc date");
	
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	System.out.println("Before V No");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:i3::content")).sendKeys("123456");
    try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("after V No");
	
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	System.out.println("Before save");
	  driver.findElement(By.xpath("//a[.='Save and Close']")).click();
    try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("after save");
	
}


@And("Enter Valus in Invoice Header")
	public void enterDetailsInInvoiceHeader(String invoicenumber,String  amount, String supplier) {
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i2::content")).sendKeys(invoicenumber);
	
	try {
		Thread.sleep(1000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	Select sc = new Select(driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:soc1::content")));
	System.out.print("Dropdwn :");
	sc.selectByIndex(2);
	
//	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:soc1::content")).sendKeys(Ccy);
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i3::content")).sendKeys(amount);
	driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i3::content")).sendKeys(Keys.TAB);
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("Before test supplier");
	
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:ic3::content")).sendKeys(supplier);
    //driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r3:0:ic3::content")).sendKeys(Keys.ENTER);
	    
    System.out.println("After test supplier");
    try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("Before description");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i4::content")).sendKeys("test");
    try {
		Thread.sleep(5000);
	}
	catch(Exception e) {
		System.out.print(e);}
	System.out.println("after description");}


	
	
@And("Enter Valus in Accounting")
public void enterDetailsInAcccounting() {

	
	driver.findElement(By.xpath("//a[.='Accounting']")).click();
	try {
		Thread.sleep(2000);
	}
	catch(Exception e) {
		System.out.print(e);}
	
	System.out.println("Before acc date");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:id4::content")).sendKeys("03/01/22");
    
	
	System.out.println("Before V No");
    driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:i3::content")).sendKeys("123456");
   
	
}

@And("Click on save")
public void saveClick() {
	 driver.findElement(By.xpath("//a[.='Save and Close']")).click();
	  try {
			Thread.sleep(5000);
		}
		catch(Exception e) {
			System.out.print(e);}}


}
