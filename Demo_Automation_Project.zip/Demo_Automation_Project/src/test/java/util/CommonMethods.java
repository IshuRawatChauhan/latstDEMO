package util;


import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.logging.FileHandler;

import org.apache.commons.io.CopyUtils;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.model.Report;
import com.aventstack.extentreports.reporter.FileUtil;

import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;



public class CommonMethods {
	private WebDriver driver;

	// 2. Constructor of the page class:
	public CommonMethods(WebDriver driver) {
		this.driver = driver;
	}
	
		public void delay() {

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
  
	}
		
		public void clickLink(String strLink) {
		   driver.findElement(By.xpath("//a[.='"+strLink+"']")).click();
		}
		public void clickCreateButton() {
				driver.findElement(By.xpath("//button[@id='pt1:_FOr1:1:_FONSr2:0:_FOTsr1:0:pm1:r1:0:r1:0:ITPdtl:0:AT1:_ATp:ct2']")).click();
				try {
					Thread.sleep(3000);
				}
				catch(Exception e) {
					System.out.print(e);}
			}
		public void clickButton(String strBTN) {
			  driver.findElement(By.id(strBTN)).click();
				
			}
		public boolean isLinkPresent(String strLink) {
			  return driver.findElement(By.xpath("//a[.='"+strLink+"']")).isDisplayed();
			}
}
