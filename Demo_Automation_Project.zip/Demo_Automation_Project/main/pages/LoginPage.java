package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class LoginPage {

	 WebDriver driver;
	 
	 private By userName = By.id("userid");
		private By password = By.id("password");
		private By loginButton = By.name("btnActive");
	
	// 2. Constructor of the page class:
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public String getLoginPageTitle() throws IOException {
		
		return driver.getTitle();
	}


	public void enterUserName(String strUserName) {
		driver.findElement(userName).sendKeys(strUserName);
	}
	public boolean userNameExists() {
		return driver.findElement(userName).isDisplayed();
		
	}
	public void enterPassword(String pwd) throws IOException {
		driver.findElement(password).sendKeys(pwd);
	}
	public boolean passwordExists() throws IOException {
	
		return driver.findElement(password).isDisplayed();
	}
	public boolean loginButtonExists() {
		return driver.findElement(loginButton).isDisplayed();
	}
	public void clickOnLogin() {
		driver.findElement(loginButton).click();
	}
	public boolean linkExists(String pName) {
		return driver.findElement(By.xpath("//a[.='"+pName+"']")).isDisplayed();
	}
	
}
