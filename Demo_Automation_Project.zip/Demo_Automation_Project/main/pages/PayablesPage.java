package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;

public class PayablesPage {

	private WebDriver driver;

	// 2. Constructor of the page class:
	public PayablesPage(WebDriver driver) {
		this.driver = driver;
	}

	@And("click on group payables")
	public void click_on_group_payable_button() {
	   System.out.println("Step3: user is clicking on Login Button");
	   driver.findElement(By.name("btnActive")).click();
	}
	
@And("I enter the details in invoice header {string} and {string} and {string}")
	public void enterValuesInInvoiceHeader(String invoicenumber,String  Ccy,String  amount) {
		Select objCurrency = new Select(driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i2::content")));
		driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i2::content")).sendKeys(invoicenumber);
		objCurrency.selectByValue("EUR");
		driver.findElement(By.id("pt1:_FOr1:1:_FONSr2:0:MAnt2:1:pm1:r1:0:ap1:r2:0:i3::content")).sendKeys(amount);
		
	}
}
