package util;

public class Base {

}
